package BaseTest;
import TestObjects.Register_Login;
import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;

public class Base_test {
        public ChromeDriver chromeDriver;
        public static String Url = "https://online.ntlogistics.vn/auth/register";
        public static String WebDriver = "webdriver.chrome.driver";
        public String Link_WebDriver = "D:\\Automation testing\\web project\\Java\\Demo2\\src\\main\\resources\\chromedriver.exe";

        @Before
        public void SetUp(){
        System.setProperty(WebDriver, Link_WebDriver);
        chromeDriver = new ChromeDriver();
        chromeDriver.get(Url);
        chromeDriver.manage().window().maximize();
        chromeDriver.manage().timeouts(). implicitlyWait(70, TimeUnit.MINUTES); //time out is wait time
        }

        @After
        public void TearDown() throws InterruptedException
        {
            Thread.sleep(2000);
            chromeDriver.quit();
        }
}
