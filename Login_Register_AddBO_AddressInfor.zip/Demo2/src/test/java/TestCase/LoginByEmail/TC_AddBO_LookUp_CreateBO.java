package TestCase.LoginByEmail;

import BaseTest.Base_test;
import TestObjects.LoginByEmail.AddBO_LookUp_CreateBO;
import TestObjects.LoginByEmail.Address;
import TestObjects.LoginByEmail.ServicesInformation;
import TestObjects.Register_Login;
import org.junit.Test;

public class TC_AddBO_LookUp_CreateBO extends Base_test {
    Register_Login register_login;
    AddBO_LookUp_CreateBO addBO_lookUp_createBO;
    Address address;
    ServicesInformation servicesInformation;

    /*----The sender / receiver information is not available----*/
    @Test
    public void TC_addBO_lookUp_createBO() throws InterruptedException{
        register_login = new Register_Login(chromeDriver);
        addBO_lookUp_createBO = new AddBO_LookUp_CreateBO(chromeDriver);
        address = new Address(chromeDriver);
        servicesInformation = new ServicesInformation(chromeDriver);

        /*----Login----*/
        register_login.LoginContinue();
        register_login.EmailLogin("thu811103@gmail.com");
        register_login.PasswordLogin("Thu@123456");
        register_login.ButtonLogin();

        /*----check Link Add BO----*/
        addBO_lookUp_createBO.LinkAddBO();
        addBO_lookUp_createBO.LinkLookUp_CreateBO();

        //----check sender infor----
        addBO_lookUp_createBO.CheckSender();

       // ----Add new sender infor----
        addBO_lookUp_createBO.ButtonSenderAddress();
        address.AddSenderInfor("Nguyễn Văn A","Văn A", "0934566977"," Hồ Chí Minh"," Quận 12"," Phường Đông Hưng Thuận", "123 Tô Ký");
        address.PopUpOKSenderAddress();

        //----Select sender infor----
        addBO_lookUp_createBO.LinkAddBO();
        addBO_lookUp_createBO.LinkLookUp_CreateBO();
        addBO_lookUp_createBO.SelectSenderInfor("Nguyễn Văn A");

        /*----Check receiver infor----*/
        addBO_lookUp_createBO.CheckReceiver();

        /*----Add new receiver infor----*/
        addBO_lookUp_createBO.ButtonReceiverAddress();
        address.AddReceiverInfor("Nguyễn Văn B","Văn B", "0934566911"," Hồ Chí Minh"," Quận 12"," Phường Đông Hưng Thuận", "123 Quang Trung");
        address.PopUpOKReceiverAddress();

        //----Select sender infor----
        addBO_lookUp_createBO.LinkAddBO();
        addBO_lookUp_createBO.LinkLookUp_CreateBO();
        addBO_lookUp_createBO.SelectSenderInfor("Nguyễn Văn A");
        /*----Select Receiver infor----*/
        addBO_lookUp_createBO.SelectReceiverInfor("Nguyễn Văn B");

        /*----Services infor----*/
        servicesInformation.ServiceInfor("111","Người Gửi Thanh Toán Ngay",
                "Hàng hóa", "2","1","2","4","100000",
                " ", " "," ","2020-09-21"," "," ","","");


        /*----Add infor----*/
        addBO_lookUp_createBO.ButtonPriceSeriver();
        addBO_lookUp_createBO.ButtonAddMenu();
    }

    /*----The sender / receiver information is available----*/
    @Test
    public void TC_addBO_lookUp_createBO2() throws InterruptedException{
        register_login = new Register_Login(chromeDriver);
        addBO_lookUp_createBO = new AddBO_LookUp_CreateBO(chromeDriver);
        address = new Address(chromeDriver);
        servicesInformation = new ServicesInformation(chromeDriver);

        /*----Login----*/
        register_login.LoginContinue();
        register_login.EmailLogin("thu811103@gmail.com");
        register_login.PasswordLogin("Thu@123456");
        register_login.ButtonLogin();

        /*----check Link Add BO----*/
        addBO_lookUp_createBO.LinkAddBO();
        addBO_lookUp_createBO.LinkLookUp_CreateBO();


        //----Select sender infor----
        addBO_lookUp_createBO.SelectSenderInfor("Nguyễn Văn A");

        /*----Select Receiver infor----*/
        addBO_lookUp_createBO.SelectReceiverInfor("Nguyễn Văn B");

        /*----Services infor----*/
        servicesInformation.ServiceInfor("111","Người Gửi Thanh Toán Ngay",
                "Hàng hóa", "2","1","2","4","100000",
                " ", " "," ","2020-09-21"," "," ","","");


        /*----Add infor----*/
        addBO_lookUp_createBO.ButtonPriceSeriver();
        addBO_lookUp_createBO.ButtonAddMenu();
    }

    /*----The sender is not available / receiver information is available----*/
    @Test
    public void TC_addBO_lookUp_createBO3() throws InterruptedException{
        register_login = new Register_Login(chromeDriver);
        addBO_lookUp_createBO = new AddBO_LookUp_CreateBO(chromeDriver);
        address = new Address(chromeDriver);
        servicesInformation = new ServicesInformation(chromeDriver);

        /*----Login----*/
        register_login.LoginContinue();
        register_login.EmailLogin("thu811103@gmail.com");
        register_login.PasswordLogin("Thu@123456");
        register_login.ButtonLogin();

        /*----check Link Add BO----*/
        addBO_lookUp_createBO.LinkAddBO();
        addBO_lookUp_createBO.LinkLookUp_CreateBO();

        //----check sender infor----
        addBO_lookUp_createBO.CheckSender();

        // ----Add new sender infor----
        addBO_lookUp_createBO.ButtonSenderAddress();
        address.AddSenderInfor("Nguyễn Văn A","Văn A", "0934566977"," Hồ Chí Minh"," Quận 12"," Phường Đông Hưng Thuận", "123 Tô Ký");
        address.PopUpOKSenderAddress();

        //----Select sender infor----
        addBO_lookUp_createBO.LinkAddBO();
        addBO_lookUp_createBO.LinkLookUp_CreateBO();
        addBO_lookUp_createBO.SelectSenderInfor("Nguyễn Văn A");

        /*----Check receiver infor----*/
        addBO_lookUp_createBO.SelectReceiverInfor("Nguyễn Văn B");

        /*----Services infor----*/
        servicesInformation.ServiceInfor("111","Người Gửi Thanh Toán Ngay",
                "Hàng hóa", "2","1","2","4","100000",
                " ", " "," ","2020-09-21"," "," ","","");


        /*----Add infor----*/
        addBO_lookUp_createBO.ButtonPriceSeriver();
        addBO_lookUp_createBO.ButtonAddMenu();
    }

    /*----The sender is available / receiver information is not available----*/
    @Test
    public void TC_addBO_lookUp_createBO4() throws InterruptedException{
        register_login = new Register_Login(chromeDriver);
        addBO_lookUp_createBO = new AddBO_LookUp_CreateBO(chromeDriver);
        address = new Address(chromeDriver);
        servicesInformation = new ServicesInformation(chromeDriver);

        /*----Login----*/
        register_login.LoginContinue();
        register_login.EmailLogin("thu811103@gmail.com");
        register_login.PasswordLogin("Thu@123456");
        register_login.ButtonLogin();

        /*----check Link Add BO----*/
        addBO_lookUp_createBO.LinkAddBO();
        addBO_lookUp_createBO.LinkLookUp_CreateBO();
        addBO_lookUp_createBO.SelectSenderInfor("Nguyễn Văn A");

        /*----Check receiver infor----*/
        addBO_lookUp_createBO.CheckReceiver();

        /*----Add new receiver infor----*/
        addBO_lookUp_createBO.ButtonReceiverAddress();
        address.AddReceiverInfor("Nguyễn Văn B","Văn B", "0934566911"," Hồ Chí Minh"," Quận 12"," Phường Đông Hưng Thuận", "123 Quang Trung");
        address.PopUpOKReceiverAddress();

        //----Select sender infor----
        addBO_lookUp_createBO.LinkAddBO();
        addBO_lookUp_createBO.LinkLookUp_CreateBO();
        addBO_lookUp_createBO.SelectSenderInfor("Nguyễn Văn A");
        /*----Select Receiver infor----*/
        addBO_lookUp_createBO.SelectReceiverInfor("Nguyễn Văn B");

        /*----Services infor----*/
        servicesInformation.ServiceInfor("111","Người Gửi Thanh Toán Ngay",
                "Hàng hóa", "2","1","2","4","100000",
                " ", " "," ","2020-09-21"," "," ","","");


        /*----Add infor----*/
        addBO_lookUp_createBO.ButtonPriceSeriver();
        addBO_lookUp_createBO.ButtonAddMenu();
    }

    /*----The sender is not available/ Enter user information directly----*/
    @Test
    public void TC_addBO_lookUp_createBO5() throws InterruptedException{
        register_login = new Register_Login(chromeDriver);
        addBO_lookUp_createBO = new AddBO_LookUp_CreateBO(chromeDriver);
        address = new Address(chromeDriver);
        servicesInformation = new ServicesInformation(chromeDriver);

        /*----Login----*/
        register_login.LoginContinue();
        register_login.EmailLogin("thu811103@gmail.com");
        register_login.PasswordLogin("Thu@123456");
        register_login.ButtonLogin();

        /*----check Link Add BO----*/
        addBO_lookUp_createBO.LinkAddBO();
        addBO_lookUp_createBO.LinkLookUp_CreateBO();

      //----check sender infor----
        addBO_lookUp_createBO.CheckSender();

        // ----Add new sender infor----
        addBO_lookUp_createBO.ButtonSenderAddress();
        address.AddSenderInfor("Nguyễn Văn A","Văn A", "0934566977"," Hồ Chí Minh"," Quận 12"," Phường Đông Hưng Thuận", "123 Tô Ký");
        address.PopUpOKSenderAddress();

        //----Select sender infor----
        addBO_lookUp_createBO.LinkAddBO();
        addBO_lookUp_createBO.LinkLookUp_CreateBO();
        addBO_lookUp_createBO.SelectSenderInfor("Nguyễn Văn A");

      /*----Check receiver infor----*/
        addBO_lookUp_createBO.AddReceiverInfor("Nguyễn Văn D","Di", "0934566977"," Hồ Chí Minh"," Quận 1"," Phường Bến Nghé", "123 Tô Ký");

        /*----Services infor----*/
        servicesInformation.ServiceInfor("111","Người Gửi Thanh Toán Ngay",
                "Hàng hóa", "2","1","2","4","100000",
                " ", " "," ","2020-09-21"," "," ","","");


        /*----Add infor----*/
        addBO_lookUp_createBO.ButtonPriceSeriver();
        addBO_lookUp_createBO.ButtonAddMenu();
    }

    /*----The sender is available / Enter user information directly----*/
    @Test
    public void TC_addBO_lookUp_createBO6() throws InterruptedException{
        register_login = new Register_Login(chromeDriver);
        addBO_lookUp_createBO = new AddBO_LookUp_CreateBO(chromeDriver);
        address = new Address(chromeDriver);
        servicesInformation = new ServicesInformation(chromeDriver);

        /*----Login----*/
        register_login.LoginContinue();
        register_login.EmailLogin("thu811103@gmail.com");
        register_login.PasswordLogin("Thu@123456");
        register_login.ButtonLogin();

        /*----check Link Add BO----*/
        addBO_lookUp_createBO.LinkAddBO();
        addBO_lookUp_createBO.LinkLookUp_CreateBO();
        addBO_lookUp_createBO.SelectSenderInfor("Nguyễn Văn A");

        /*----Select Receiver infor----*/
        addBO_lookUp_createBO.AddReceiverInfor("Nguyễn Văn D","Di", "0934566977"," Hồ Chí Minh"," Quận 1"," Phường Bến Nghé", "123 Tô Ký");

        /*----Services infor----*/
        servicesInformation.ServiceInfor("111","Người Gửi Thanh Toán Ngay",
                "Hàng hóa", "2","1","2","4","100000",
                " ", " "," ","2020-09-21"," "," ","","");


        /*----Add infor----*/
        addBO_lookUp_createBO.ButtonPriceSeriver();
        addBO_lookUp_createBO.ButtonAddMenu();
    }
}
