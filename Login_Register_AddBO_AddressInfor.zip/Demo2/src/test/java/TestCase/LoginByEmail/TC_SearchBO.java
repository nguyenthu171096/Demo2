package TestCase.LoginByEmail;
import BaseTest.Base_test;
import TestObjects.LoginByEmail.SearchBO;
import TestObjects.Register_Login;
import org.junit.Test;
import org.openqa.selenium.chrome.ChromeDriver;

public class TC_SearchBO extends Base_test {
    Register_Login register_login;
    SearchBO searchBO;

    @Test
    public void TC_Search() throws InterruptedException {
        register_login = new Register_Login(chromeDriver);
        searchBO = new SearchBO(chromeDriver);

        register_login.LoginContinue();
        register_login.EmailLogin("thu811103@gmail.com");
        register_login.PasswordLogin("Thu@123456");
        register_login.ButtonLogin();

        searchBO.LinkSearchBO();
        searchBO.Search("CP36634117");
    }
}
