package TestCase.LoginByEmail;

import BaseTest.Base_test;
import TestObjects.LoginByEmail.Address;
import TestObjects.LoginByEmail.Create_multiple_shipping_points;
import TestObjects.Register_Login;
import org.junit.Test;

public class TC_Create_multiple_shipping_points extends Base_test {
    Register_Login register_login;
    Create_multiple_shipping_points create_multiple_shipping_points;
    Address address;

    /*----Exist customer----*/
    @Test
    public void TC_addBO_lookUp_createBO() throws InterruptedException {
        register_login = new Register_Login(chromeDriver);
        create_multiple_shipping_points = new Create_multiple_shipping_points(chromeDriver);

        /*----Login----*/
        register_login.LoginContinue();
        register_login.EmailLogin("thu811103@gmail.com");
        register_login.PasswordLogin("Thu@123456");
        register_login.ButtonLogin();

        /*----check Link Add BO----*/
        create_multiple_shipping_points.LinkAddBO();
        create_multiple_shipping_points.LinkCreate_multiple_shipping_points();
        create_multiple_shipping_points.ReceiverInfor("Nguyễn Văn A");

        /*----upload file----*/
        create_multiple_shipping_points.UploadFile();
        create_multiple_shipping_points.PushData();
        create_multiple_shipping_points.InvoiceCreation();
        create_multiple_shipping_points.CreateBO();
    }

    /*----No exist customer----*/
    @Test
    public void TC_addBO_lookUp_createBO1() throws InterruptedException {
        register_login = new Register_Login(chromeDriver);
        create_multiple_shipping_points = new Create_multiple_shipping_points(chromeDriver);
        address = new Address(chromeDriver);

        /*----Login----*/
        register_login.LoginContinue();
        register_login.EmailLogin("thu811103@gmail.com");
        register_login.PasswordLogin("Thu@123456");
        register_login.ButtonLogin();

        /*----Select sender----*/
        create_multiple_shipping_points.LinkAddBO();
        create_multiple_shipping_points.LinkCreate_multiple_shipping_points();
        create_multiple_shipping_points.ReceiverInfor1();

        /*----Add Sender----*/
        address.LinkAddress();
        address.LinkReceiverAddress();
        address.AddReceiverInfor("Nguyễn Văn B","Văn A", "0934566977"," Hồ Chí Minh"," Quận 12"," Phường Đông Hưng Thuận", "123 Tô Ký");
        address.PopUpOKReceiverAddress();

        /*----Select sender----*/
        Thread.sleep(2000);
        create_multiple_shipping_points.LinkAddBO();
        create_multiple_shipping_points.LinkCreate_multiple_shipping_points();
        create_multiple_shipping_points.ReceiverInfor("Nguyễn Văn B");

        /*----upload file----*/
        create_multiple_shipping_points.UploadFile();
        create_multiple_shipping_points.PushData();
        create_multiple_shipping_points.InvoiceCreation();
        create_multiple_shipping_points.CreateBO();
    }

    /*----Downloaf file--------*/
    @Test
    public void TC_Downloadfile() throws InterruptedException {
        register_login = new Register_Login(chromeDriver);
        create_multiple_shipping_points = new Create_multiple_shipping_points(chromeDriver);

        /*----Login----*/
        register_login.LoginContinue();
        register_login.EmailLogin("thu811103@gmail.com");
        register_login.PasswordLogin("Thu@123456");
        register_login.ButtonLogin();

        create_multiple_shipping_points.LinkAddBO();
        create_multiple_shipping_points.LinkCreate_multiple_shipping_points();
        create_multiple_shipping_points.DownloadFile();
    }
}
