package TestCase;
import BaseTest.Base_test;
import TestObjects.Register_Login;
import org.junit.Test;

public class TC_Register extends Base_test {
    Register_Login register_login;

    @Test
    public void TC_Register() throws InterruptedException {
        register_login = new Register_Login(chromeDriver);

        register_login.UserName("Nguyễn Văn A");
        register_login.IDCard("0254019538");
        register_login.Telephone("0770739557");
        register_login.Email("cankha1234@gmail.com");
        register_login.TypeCustomer("Công ty/ Đại lý");
        register_login.Password("Can@00000000");
        register_login.Repassword("Can@00000000");
        register_login.IDSalesMan("Abcd1234");

        register_login.ScollPage();
        register_login.ButtonRegister();
        register_login.PopUpRegister();
    }

    @Test
    public void TC_Login() throws InterruptedException{
        register_login = new Register_Login(chromeDriver);

        register_login.LoginContinue();
        register_login.EmailLogin("thu811103@gmail.com");
        register_login.PasswordLogin("Thu@123456");
        register_login.ButtonLogin();
    }

}
