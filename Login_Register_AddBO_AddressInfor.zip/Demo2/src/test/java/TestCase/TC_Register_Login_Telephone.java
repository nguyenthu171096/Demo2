package TestCase;
import BaseTest.Base_test;
import TestObjects.Register_Login;
import TestObjects.Register_Login_Telephone;
import org.junit.Test;

public class TC_Register_Login_Telephone extends Base_test {
    Register_Login_Telephone register_login_telephone;

    @Test
    public void TC_Login() throws InterruptedException{
        register_login_telephone = new Register_Login_Telephone(chromeDriver);

        register_login_telephone.LinkLoginContinue();
        register_login_telephone.ButtonLoginUsingTelephone();
        register_login_telephone.Telephone("0934144669");
        register_login_telephone.Password("1234@abcd");
        register_login_telephone.ButtonLogin();
    }
}

