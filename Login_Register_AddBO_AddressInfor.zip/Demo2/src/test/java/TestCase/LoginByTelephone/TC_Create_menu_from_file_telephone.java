package TestCase.LoginByTelephone;

import BaseTest.Base_test;
import TestObjects.LoginByEmail.Address;
import TestObjects.LoginByEmail.Create_menu_from_file;
import TestObjects.Register_Login;
import TestObjects.Register_Login_Telephone;
import org.junit.Test;

public class TC_Create_menu_from_file_telephone extends Base_test {
    Register_Login_Telephone register_login_telephone;
    Create_menu_from_file create_menu_from_file;
    Address address;

    /*----Exist customer----*/
    @Test
    public void TC_addBO_lookUp_createBO() throws InterruptedException {
        register_login_telephone = new Register_Login_Telephone(chromeDriver);
        create_menu_from_file = new Create_menu_from_file(chromeDriver);

        /*----Login----*/
        register_login_telephone.LinkLoginContinue();
        register_login_telephone.ButtonLoginUsingTelephone();
        register_login_telephone.Telephone("0934144669");
        register_login_telephone.Password("1234@abcd");
        register_login_telephone.ButtonLogin();

        /*----check Link Add BO----*/
        create_menu_from_file.LinkAddBO();
        create_menu_from_file.LinkCreate_menu_from_file();
        create_menu_from_file.SenderInfor("Nguyễn Văn A");

        /*----upload file----*/
        create_menu_from_file.UploadFile();
        create_menu_from_file.PushData();
        create_menu_from_file.InvoiceCreation();
        create_menu_from_file.CreateBO();
    }

    /*----No exist customer----*/
    @Test
    public void TC_addBO_lookUp_createBO1() throws InterruptedException {
        register_login_telephone = new Register_Login_Telephone(chromeDriver);
        create_menu_from_file = new Create_menu_from_file(chromeDriver);
        address = new Address(chromeDriver);

        /*----Login----*/
        register_login_telephone.LinkLoginContinue();
        register_login_telephone.ButtonLoginUsingTelephone();
        register_login_telephone.Telephone("0934144669");
        register_login_telephone.Password("1234@abcd");
        register_login_telephone.ButtonLogin();

        /*----Select sender----*/
        create_menu_from_file.LinkAddBO();
        create_menu_from_file.LinkCreate_menu_from_file();
        create_menu_from_file.SenderInfor1();

        /*----Add Sender----*/
        address.LinkAddress();
        address.LinkSenderInfor();
        address.AddSenderInfor("Nguyễn Văn B","Văn A", "0934566977"," Hồ Chí Minh"," Quận 12"," Phường Đông Hưng Thuận", "123 Tô Ký");
        address.PopUpOKSenderAddress();

        /*----Select sender----*/
        Thread.sleep(2000);
        create_menu_from_file.LinkAddBO();
        create_menu_from_file.LinkCreate_menu_from_file();
        create_menu_from_file.SenderInfor("Nguyễn Văn B");

        /*----upload file----*/
        create_menu_from_file.UploadFile();
        create_menu_from_file.PushData();
        create_menu_from_file.InvoiceCreation();
        create_menu_from_file.CreateBO();
    }

    /*----Downloaf file--------*/
    @Test
    public void TC_Downloadfile() throws InterruptedException {
        register_login_telephone = new Register_Login_Telephone(chromeDriver);
        create_menu_from_file = new Create_menu_from_file(chromeDriver);
        address = new Address(chromeDriver);

        /*----Login----*/
        register_login_telephone.LinkLoginContinue();
        register_login_telephone.ButtonLoginUsingTelephone();
        register_login_telephone.Telephone("0934144669");
        register_login_telephone.Password("1234@abcd");
        register_login_telephone.ButtonLogin();

        create_menu_from_file.LinkAddBO();
        create_menu_from_file.LinkCreate_menu_from_file();
        create_menu_from_file.DownloadFile();
    }
}
