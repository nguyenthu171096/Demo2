package TestCase.LoginByTelephone;
import BaseTest.Base_test;
import TestObjects.LoginByEmail.SearchBO;
import TestObjects.Register_Login;
import TestObjects.Register_Login_Telephone;
import org.junit.Test;

public class TC_SearchBO_Telephone extends Base_test {
    Register_Login_Telephone register_login_telephone;
    SearchBO searchBO;

    @Test
    public void TC_Search() throws InterruptedException {
        register_login_telephone = new Register_Login_Telephone(chromeDriver);
        searchBO = new SearchBO(chromeDriver);

        register_login_telephone.LinkLoginContinue();
        register_login_telephone.ButtonLoginUsingTelephone();
        register_login_telephone.Telephone("0934144669");
        register_login_telephone.Password("1234@abcd");
        register_login_telephone.ButtonLogin();

        searchBO.LinkSearchBO();
        searchBO.Search("CP36634117");
    }
}
