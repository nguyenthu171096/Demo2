package TestObjects;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Register_Login {
    ChromeDriver chromeDriver;
    public Register_Login(ChromeDriver _chromeDriver)
    {
        this.chromeDriver = _chromeDriver;
        PageFactory.initElements(_chromeDriver,this);
    }
    /**********Register**********/
    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-register/nb-card/nb-card-body/div/div[2]/form/div/div/div/div[1]/input")
    private WebElement _UserName;
    public void UserName (String UserName1) throws InterruptedException{
        _UserName.sendKeys(UserName1);
        Thread.sleep(2000);
    }

    @FindBy(xpath="/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-register/nb-card/nb-card-body/div/div[2]/form/div/div/div/div[2]/div[1]/div/input")
    private WebElement _IDCard;
    public void IDCard (String IDCard1) throws InterruptedException{
        _IDCard.sendKeys(IDCard1);
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-register/nb-card/nb-card-body/div/div[2]/form/div/div/div/div[2]/div[2]/div/input")
    private WebElement _Telephone;
    public void Telephone (String Telephone1) throws InterruptedException{
        _Telephone.sendKeys(Telephone1);
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-register/nb-card/nb-card-body/div/div[2]/form/div/div/div/div[3]/div[1]/div/input")
    private WebElement _Email;
    public void Email (String Email1) throws InterruptedException{
        _Email.sendKeys(Email1);
        Thread.sleep(2000);
    }

    @FindBy(name = "partner_type")
    private WebElement _TypeCustomer;
    public void TypeCustomer (String TypeCustomer1) throws InterruptedException{
        Select TC = new Select(_TypeCustomer);
        TC.selectByVisibleText(TypeCustomer1);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-register/nb-card/nb-card-body/div/div[2]/form/div/div/div/div[4]/input")
    private WebElement _Password;
    public void Password (String Password1) throws InterruptedException{
        _Password.sendKeys(Password1);
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-register/nb-card/nb-card-body/div/div[2]/form/div/div/div/div[5]/input")
    private WebElement _Repassword;
    public void Repassword (String Repassword1) throws InterruptedException{
        _Repassword.sendKeys(Repassword1);
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-register/nb-card/nb-card-body/div/div[2]/form/div/div/div/div[6]/input")
    private WebElement _IDSalesMan;
    public void IDSalesMan (String IDSalesMan1) throws InterruptedException{
        _IDSalesMan.sendKeys(IDSalesMan1);
        Thread.sleep(2000);
    }

    public void ScollPage() throws InterruptedException{
        JavascriptExecutor js = (JavascriptExecutor) chromeDriver;
        js.executeScript("arguments[0].scrollIntoView();", _ButtonRegister);
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-register/nb-card/nb-card-body/div/div[2]/form/div/button")
    private WebElement _ButtonRegister;
    public void ButtonRegister () throws InterruptedException{
        _ButtonRegister.click();
    }

    public void PopUpRegister() throws InterruptedException{
        Thread.sleep(7000);
        Alert alert = chromeDriver.switchTo().alert();
        alert.accept();
    }

    /**********Link đăng nhập ngay**********/
    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-register/nb-card/nb-card-body/section/a")
    private WebElement _LoginContinue;
    public void LoginContinue() throws InterruptedException{
        JavascriptExecutor js = (JavascriptExecutor) chromeDriver;
        js.executeScript("arguments[0].scrollIntoView();", _LoginContinue);
        Thread.sleep(2000);
        _LoginContinue.click();
    }

    /**********Login**********/
    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-login/nb-card/nb-card-body/div/div[2]/form/div/div[1]/input")
    private WebElement _EmailLogin;
    public void EmailLogin(String EmailLogin1) throws InterruptedException{
        _EmailLogin.sendKeys(EmailLogin1);
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-login/nb-card/nb-card-body/div/div[2]/form/div/div[2]/input")
    private WebElement _PasswordLogin;
    public void PasswordLogin(String PasswordLogin1) throws InterruptedException{
        _PasswordLogin.sendKeys(PasswordLogin1);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-login/nb-card/nb-card-body/div/div[2]/form/div/button")
    private WebElement _ButtonLogin;
    public void ButtonLogin() throws InterruptedException{
        _ButtonLogin.click();
        Thread.sleep(7000);
    }

}
