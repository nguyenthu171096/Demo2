package TestObjects.LoginByEmail;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Create_menu_from_file {
    ChromeDriver chromeDriver;
    public Create_menu_from_file(ChromeDriver chromeDriver)
    {
        this.chromeDriver = chromeDriver;
        PageFactory.initElements(chromeDriver,this);
    }

    @FindBy(linkText = "Tạo vận đơn")
    private WebElement _LinkAddBO;
    public void LinkAddBO() throws InterruptedException{
        _LinkAddBO.click();
        Thread.sleep(2000);
    }

    @FindBy(linkText = "Tạo đơn từ file")
    private WebElement _LinkCreate_menu_from_file;
    public void LinkCreate_menu_from_file() throws InterruptedException{
        _LinkCreate_menu_from_file.click();
        Thread.sleep(2000);
    }

    @FindBy(id = "partner_address_id")
    private WebElement _SenderInfor;
    public void SenderInfor(String SenderInfor1) throws InterruptedException{
        Actions builderPM = new Actions( chromeDriver);
        Action actionPM  = builderPM.click(_SenderInfor).sendKeys(SenderInfor1 + Keys.ENTER).build();
        actionPM.perform();
        Thread.sleep(4000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-listing/nb-card/nb-card-body/form/div/div[1]/div/div[2]/div[2]/div[1]/button")
    private WebElement _DownloadFile;
    public void DownloadFile() throws InterruptedException{
        _DownloadFile.click();
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-listing/nb-card/nb-card-body/form/div/div[1]/div/div[2]/div[1]/div/div/div/input")
    private WebElement _UploadFile;
    public void UploadFile() throws InterruptedException{
        _UploadFile.sendKeys("D:\\Automation testing\\web project\\Java\\Demo2\\UploadFile\\Mau-Bill.xlsm");
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-listing/nb-card/nb-card-body/form/div/div[1]/div/div[2]/div[2]/div[2]/div/button")
    private WebElement _PushData;
    public void PushData() throws InterruptedException{
        _PushData.click();
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-listing/nb-card/nb-card-body/form/div/div[1]/div/div[2]/div[2]/div[3]/button")
    private WebElement _InvoiceCreation;
    public void InvoiceCreation() throws InterruptedException{
        _InvoiceCreation.click();
        Thread.sleep(5000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-showcase-popup/div/div[3]/button")
    private WebElement _CreateBO;
    public void CreateBO() throws InterruptedException{
        _CreateBO.click();
        Thread.sleep(2000);
    }

    @FindBy(id = "partner_address_id")
    private WebElement _SenderInfor1;
    public void SenderInfor1() throws InterruptedException{
        Actions builder = new Actions( chromeDriver);
        Action action  = builder.click(_SenderInfor1).build();
        action.perform();
        Thread.sleep(4000);
    }
}
