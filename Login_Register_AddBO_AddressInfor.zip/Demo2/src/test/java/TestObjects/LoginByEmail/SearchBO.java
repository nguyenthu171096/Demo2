package TestObjects.LoginByEmail;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class SearchBO {
    ChromeDriver chromeDriver;
    public SearchBO(ChromeDriver chromeDriver){
        this.chromeDriver = chromeDriver;
        PageFactory.initElements(chromeDriver,this);
    }

    @FindBy(linkText = "Tra cứu vận đơn")
    private WebElement _LinkSearchBO;
    public void LinkSearchBO() throws InterruptedException{
        _LinkSearchBO.click();
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-search/nb-card/nb-card-body/div/div/form/div[1]/div[1]/div/input")
    private WebElement _TextboxSearch;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-search/nb-card/nb-card-body/div/div/form/div[1]/div[2]/div/button")
    private WebElement _ButtonSearch;
    public void Search(String Search1) throws InterruptedException{
        _TextboxSearch.sendKeys(Search1);
        Thread.sleep(2000);
        _ButtonSearch.click();
        Thread.sleep(7000);
    }
}