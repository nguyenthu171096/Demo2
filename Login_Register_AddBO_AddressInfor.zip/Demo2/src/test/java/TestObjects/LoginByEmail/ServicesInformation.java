package TestObjects.LoginByEmail;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ServicesInformation {
    ChromeDriver chromeDriver;
    public ServicesInformation(ChromeDriver chromeDriver){
        this.chromeDriver = chromeDriver;
        PageFactory.initElements(chromeDriver,this);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[1]/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[3]/div/div[1]/input")
    private WebElement _ReferenceCode;
    @FindBy(id = "payment_method")
    private WebElement _PaymentMethod;
    @FindBy(id = "cargo_type")
    private WebElement _CargoType;
    @FindBy(id = "package_no")
    private WebElement _PackageNo;
    @FindBy(id = "weight")
    private WebElement _Weight;
    @FindBy(id = "length")
    private WebElement _Length;
    @FindBy(id = "width")
    private WebElement _Width;
    @FindBy(id = "height")
    private WebElement _Height;
    @FindBy(id = "cargo_value")
    private WebElement _CargoValue;
    @FindBy(id = "cod_amt")
    private WebElement _CodAmt;
    @FindBy(className = "custom-checkbox")
    private WebElement _CustomCheckbox;
    @FindBy(id = "ticket_type")
    private WebElement _TicketType;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[3]/div/div[7]/div/div[2]/nz-select[1]/div")
    private WebElement _Time;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[3]/div/div[7]/div/div[2]/nz-select[2]/div")
    private WebElement _Hour;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[3]/div/div[7]/div/div[2]/nz-select[3]/div")
    private WebElement _Minute;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[1]/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[3]/div/div[8]/textarea")
    private WebElement _ContentService;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[1]/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[3]/div/div[9]/textarea")
    private WebElement _Notes;


    public void ServiceInfor(String ReferenceCode1, String PaymentMethod1, String CargoType1, String PackageNo1, String Weight1
            , String Length1, String Width1, String Height1, String CargoValue1,String CodAmt1, String TicketType1, String Time1,
                             String Hour1, String Minute1, String ContentService1, String Notes1) throws InterruptedException{

        _ReferenceCode.sendKeys(ReferenceCode1);
        Thread.sleep(2000);

        Actions builderPM = new Actions( chromeDriver);
        Action actionPM  = builderPM.click(_PaymentMethod).sendKeys(PaymentMethod1 + Keys.ENTER).build();
        actionPM.perform();
        Thread.sleep(4000);

        Actions builderCT = new Actions( chromeDriver);
        Action actionCT  = builderCT.click(_CargoType).sendKeys(CargoType1 + Keys.ENTER).build();
        actionCT.perform();
        Thread.sleep(4000);

        _PackageNo.sendKeys(PackageNo1);
        _Weight.sendKeys(Weight1);
        _Length.sendKeys(Length1);
        _Width.sendKeys(Width1);
        _Height.sendKeys(Height1);
        _CargoValue.sendKeys(CargoValue1);
        _CodAmt.sendKeys(CodAmt1);

        _CustomCheckbox.click();
        Select select2 =new Select(_CargoType);
        select2.selectByVisibleText(CargoType1);

        Actions builder1 = new Actions( chromeDriver);
        Action action1  = builder1.click(_Time).sendKeys(Time1 + Keys.ENTER).build();
        action1.perform();
        Thread.sleep(4000);

        Actions builder2 = new Actions( chromeDriver);
        Action action2  = builder1.click(_Hour).sendKeys(Hour1 + Keys.ENTER).build();
        action2.perform();
        Thread.sleep(4000);

        Actions builder3 = new Actions( chromeDriver);
        Action action3  = builder1.click(_Minute).sendKeys(Minute1 + Keys.ENTER).build();
        action3.perform();
        Thread.sleep(4000);

        _ContentService.sendKeys(ContentService1);
        _Notes.sendKeys(Notes1);
    }
}
