package TestObjects.LoginByEmail;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddBO_LookUp_CreateBO {
    ChromeDriver chromeDriver;
    public AddBO_LookUp_CreateBO(ChromeDriver chromeDriver)
    {
        this.chromeDriver = chromeDriver;
        PageFactory.initElements(chromeDriver,this);
    }

    @FindBy(linkText = "Tạo vận đơn")
    private WebElement _LinkAddBO;
    public void LinkAddBO() throws InterruptedException{
        _LinkAddBO.click();
        Thread.sleep(2000);
    }

    @FindBy(linkText = "Tra cước & tạo đơn")
    private WebElement _LinkLookUp_CreateBO;
    public void LinkLookUp_CreateBO() throws InterruptedException{
        _LinkLookUp_CreateBO.click();
        Thread.sleep(2000);
    }
//-------------------------------Sender----Information--------------------------------------------------------------------------
   @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[1]/div/div[1]/div/div[1]/nz-select/div")
    private WebElement _CheckSender;
    public void CheckSender() throws InterruptedException{
        Actions Sender1 = new Actions( chromeDriver);
        Action _Sender1  = Sender1.click(_CheckSender).build();
        _Sender1.perform();
        Thread.sleep(2000);
        Actions Sender2 = new Actions( chromeDriver);
        Action _Sender2  = Sender2.click(_CheckSender).build();
        _Sender2.perform();
    }

    @FindBy(linkText = "Tạo điểm gửi")
    private WebElement _ButtonSenderAddress;
    public void ButtonSenderAddress() throws InterruptedException{
        _ButtonSenderAddress.click();
        Thread.sleep(2000);
    }

    public void SelectSenderInfor (String SelectSenderInfor1) throws InterruptedException{
        Actions builder = new Actions( chromeDriver );
        Action action  = builder.click(_CheckSender).sendKeys(SelectSenderInfor1 + Keys.ENTER).build();
        action.perform();
        Thread.sleep(2000);
    }
//-------------------------------Receiver----Information--------------------------------------------------------------------------
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[2]/div/div[1]/div/div[1]/nz-select/div")
    private WebElement _CheckReceiver;
    public void CheckReceiver() throws InterruptedException{
        Actions builder2 = new Actions( chromeDriver);
        Action action2  = builder2.click(_CheckReceiver).build();
        action2.perform();
        Thread.sleep(2000);
        Actions builder3 = new Actions( chromeDriver);
        Action action3  = builder3.click(_CheckReceiver).build();
        action3.perform();
    }

    @FindBy(linkText = "Tạo điểm nhận")
    private WebElement _ButtonReceiverAddress;
    public void ButtonReceiverAddress() throws InterruptedException{
        _ButtonReceiverAddress.click();
        Thread.sleep(2000);
    }

    public void SelectReceiverInfor (String SelectReceiverInfor1) throws InterruptedException{
        Actions builder = new Actions( chromeDriver );
        Action action  = builder.click(_CheckReceiver).sendKeys(SelectReceiverInfor1 + Keys.ENTER).build();
        action.perform();
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[3]/div/div[10]/button")
    private WebElement _ButtonPriceSeriver;
    public void ButtonPriceSeriver() throws InterruptedException{
        JavascriptExecutor js = (JavascriptExecutor) chromeDriver;
        js.executeScript("arguments[0].scrollIntoView();", _ButtonPriceSeriver);
        Thread.sleep(2000);
        _ButtonPriceSeriver.click();
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[1]/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div[2]/div[6]/div/div[2]/button")
    private WebElement _ButtonAddMenu;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-showcase-popup/div/div[3]/a")
    private WebElement _ButtonOK;
    public void ButtonAddMenu() throws InterruptedException{
        JavascriptExecutor js = (JavascriptExecutor) chromeDriver;
        js.executeScript("arguments[0].scrollIntoView();", _ButtonAddMenu);
        Thread.sleep(2000);
        _ButtonAddMenu.click();
        Thread.sleep(7000);
        _ButtonOK.click();
        Thread.sleep(10000);
    }
//-------------------------------Enter user information directly--------------------------------------------------------------------------
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[2]/div/div[2]/input")
    private WebElement _Reminiscent_name;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[2]/div/div[3]/input")
    private WebElement _Contact_name;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[2]/div/div[4]/input")
    private WebElement _Contact_phone;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[1]/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[2]/div/div[5]/nz-select/div")
    private WebElement _City;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[1]/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[2]/div/div[6]/nz-select/div")
    private WebElement _District;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[1]/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[2]/div/div[7]/nz-select/div")
    private WebElement _Ward;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div/div/div/div/div/nb-layout-column/app-bill-create-one/nb-card/nb-card-body/form/div/div[2]/div/div[8]/textarea")
    private WebElement _ApartmentNumber;
    public void AddReceiverInfor(String Reminiscent_name2,String ContactName2,String Telephone2,String City2,String District2,String Wards2, String ApartmentNumber2) throws InterruptedException{
        _Reminiscent_name.sendKeys(Reminiscent_name2);
        Thread.sleep(2000);
        _Contact_name.sendKeys(ContactName2);
        Thread.sleep(2000);
        _Contact_phone.sendKeys(Telephone2);
        Thread.sleep(2000);

        Actions builder = new Actions( chromeDriver );
        Action action  = builder.click(_City).sendKeys(City2 + Keys.ENTER).build();
        action.perform();
        Thread.sleep(4000);

        Actions builder1 = new Actions( chromeDriver);
        Action action1  = builder1.click(_District).sendKeys(District2 + Keys.ENTER).build();
        action1.perform();
        Thread.sleep(4000);

        Actions builder2 = new Actions( chromeDriver );
        Action action2  = builder2.click(_Ward).sendKeys(Wards2 + Keys.ENTER).build();
        action2.perform();
        Thread.sleep(4000);

        _ApartmentNumber.sendKeys(ApartmentNumber2);
        Thread.sleep(2000);
    }




}
