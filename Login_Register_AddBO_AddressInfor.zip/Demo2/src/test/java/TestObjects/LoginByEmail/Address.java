package TestObjects.LoginByEmail;
import com.sun.org.omg.SendingContext._CodeBaseImplBase;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Address {
    ChromeDriver chromeDriver;
    public Address(ChromeDriver chromeDriver)
    {
        this.chromeDriver = chromeDriver;
        PageFactory.initElements(chromeDriver,this);
    }

    @FindBy(linkText = "Sổ địa chỉ")
    private WebElement _LinkAddress;
    public void LinkAddress() throws InterruptedException{
        _LinkAddress.click();
        Thread.sleep(2000);
    }

//-------------------------------Sender----Information--------------------------------------------------------------------------
    @FindBy(linkText = "Điểm lấy hàng")
    private WebElement _LinkSenderInfor;
    public void LinkSenderInfor() throws InterruptedException{
        _LinkSenderInfor.click();
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[1]/div/div/div/div/nb-layout-column/ngx-partner-address/ngx-address-list/nb-card/nb-card-body/div/div[2]/button[2]")
    private WebElement _AddSenderAddress;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/div/div[1]/div/input")
    private WebElement _ContactName;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/div/div[2]/div/input")
    private WebElement _UserName;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/div/div[3]/div/input")
    private WebElement _Telephone;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/div/div[4]/div/nz-select/div")
    private WebElement _City;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/div/div[5]/div/nz-select/div")
    private WebElement _District;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/div/div[6]/div/nz-select/div")
    private WebElement _Wards;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/div/div[7]/div/textarea")
    private WebElement _Address;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/button")
    private WebElement _ButtonOK;

    public void AddSenderInfor(String ContactName1,String UserName1,String Telephone1,String City1,String District1,String Wards1, String Address1) throws InterruptedException{
        _AddSenderAddress.click();
        Thread.sleep(2000);
        _ContactName.sendKeys(ContactName1);
        Thread.sleep(2000);
        _UserName.sendKeys(UserName1);
        Thread.sleep(2000);
        _Telephone.sendKeys(Telephone1);
        Thread.sleep(2000);

        Actions builder = new Actions( chromeDriver );
        Action action  = builder.click(_City).sendKeys(City1 + Keys.ENTER).build();
        action.perform();
        Thread.sleep(4000);

        Actions builder1 = new Actions( chromeDriver);
        Action action1  = builder1.click(_District).sendKeys(District1 + Keys.ENTER).build();
        action1.perform();
        Thread.sleep(4000);

        Actions builder2 = new Actions( chromeDriver );
        Action action2  = builder2.click(_Wards).sendKeys(Wards1 + Keys.ENTER).build();
        action2.perform();
        Thread.sleep(4000);

        _Address.sendKeys(Address1);
        Thread.sleep(2000);
        _ButtonOK.click();
        Thread.sleep(2000);
    }

    public void PopUpOKSenderAddress() throws InterruptedException{
        Thread.sleep(2000);
        Alert alert = chromeDriver.switchTo().alert();
        alert.accept();
        Thread.sleep(2000);
    }

//-------------------------------Receiver----Information--------------------------------------------------------------------------
    @FindBy(linkText = "Điểm trả hàng")
    private WebElement _LinkReceiverInfor;
    public void LinkReceiverAddress() throws InterruptedException{
        _LinkReceiverInfor.click();
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[1]/div/div/div/div/nb-layout-column/ngx-partner-address/ngx-address-paid/nb-card/nb-card-body/div/div[2]/button[2]")
    private WebElement _LinkReceiverAddress;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/div/div[1]/div/input")
    private WebElement _ContactNameReceiverAddress;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/div/div[2]/div/input")
    private WebElement _UserNameReceiverAddress;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/div/div[3]/div/input")
    private WebElement _TelephoneReceiverAddress;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/div/div[4]/div/nz-select/div")
    private WebElement _CityReceiverAddress;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/div/div[5]/div/nz-select/div")
    private WebElement _DistrictReceiverAddress;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/div/div[6]/div/nz-select/div")
    private WebElement _WardsReceiverAddress;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/div/div[7]/div/textarea")
    private WebElement _AddressReceiverAddress;
    @FindBy(xpath = "/html/body/ngx-app/ngx-pages/ngx-one-column-layout/nb-layout/div[2]/div[2]/div/nb-windows-container/nb-window/nb-card/nb-card-body/nb-overlay-container/ngx-create-partner-address/nb-card/nb-card-body/button")
    private WebElement _ButtonOKReceiverAddress;

    public void AddReceiverInfor(String ContactNameReceiver1,String UserNameReceiver1,String TelephoneReceiver1,String CityReceiver1,String DistrictReceiver1,String WardsReceiver1, String AddressReceiver1) throws InterruptedException{

        _LinkReceiverAddress.click();
        Thread.sleep(2000);
        _ContactNameReceiverAddress.sendKeys(ContactNameReceiver1);
        Thread.sleep(2000);
        _UserNameReceiverAddress.sendKeys(UserNameReceiver1);
        Thread.sleep(2000);
        _TelephoneReceiverAddress.sendKeys(TelephoneReceiver1);
        Thread.sleep(2000);

        Actions builder = new Actions( chromeDriver );
        Action action  = builder.click(_CityReceiverAddress).sendKeys(CityReceiver1 + Keys.ENTER).build();
        action.perform();
        Thread.sleep(4000);

        Actions builder1 = new Actions( chromeDriver);
        Action action1  = builder1.click(_DistrictReceiverAddress).sendKeys(DistrictReceiver1 + Keys.ENTER).build();
        action1.perform();
        Thread.sleep(4000);

        Actions builder2 = new Actions( chromeDriver );
        Action action2  = builder2.click(_WardsReceiverAddress).sendKeys(WardsReceiver1 + Keys.ENTER).build();
        action2.perform();
        Thread.sleep(4000);

        _Address.sendKeys(AddressReceiver1);
        Thread.sleep(2000);
        _ButtonOK.click();
        Thread.sleep(2000);
    }

    public void PopUpOKReceiverAddress() throws InterruptedException{
        Thread.sleep(2000);
        Alert alert = chromeDriver.switchTo().alert();
        alert.accept();
        Thread.sleep(2000);
    }
}
