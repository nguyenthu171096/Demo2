package TestObjects;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Register_Login_Telephone {
    ChromeDriver chromeDriver;
    public Register_Login_Telephone(ChromeDriver _chromeDriver)
    {
        this.chromeDriver = _chromeDriver;
        PageFactory.initElements(_chromeDriver,this);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-register/nb-card/nb-card-body/section/a")
    private WebElement _LinkLoginContinue;

    public void ScollPageTelephone() throws InterruptedException{
        // Vị trí của phần tử mà bạn muốn scroll xuống
        JavascriptExecutor js = (JavascriptExecutor) chromeDriver;
        js.executeScript("arguments[0].scrollIntoView();", _LinkLoginContinue);
        Thread.sleep(2000);
    }

    public void LinkLoginContinue() throws InterruptedException{
        Thread.sleep(2000);
        _LinkLoginContinue.click();
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-login/nb-card/nb-card-body/div/div[2]/form/div/a")
    private WebElement _ButtonLoginUsingTelephone;
    public void ButtonLoginUsingTelephone() throws InterruptedException{
        _ButtonLoginUsingTelephone.click();
        Thread.sleep(4000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-login-phone/nb-card/nb-card-body/div/div[2]/form/div/div[1]/input")
    private WebElement _Telephone;
    public void Telephone(String Telephone1) throws InterruptedException{
        _Telephone.sendKeys(Telephone1);
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-login-phone/nb-card/nb-card-body/div/div[2]/form/div/div[2]/input")
    private WebElement _Password;
    public void Password(String Password1) throws InterruptedException{
        _Password.sendKeys(Password1);
        Thread.sleep(2000);
    }

    @FindBy(xpath = "/html/body/ngx-app/ngx-auth/nb-layout/div/div/div/div/div/nb-layout-column/nb-card/nb-card-body/nb-auth-block/ngx-login-phone/nb-card/nb-card-body/div/div[2]/form/div/button")
    private WebElement _ButtonLogin;
    public void ButtonLogin() throws InterruptedException{
        _ButtonLogin.click();
        Thread.sleep(2000);
    }
}
